setwd('C:\\Research\\Projects\\Dong X 2016 SCCNV\\mapq30\\')
dat1=read.table('mda_result.dat1_raw.txt', header=T)
dat2=read.table('mda_result.dat2_mapability.txt', header=T)
cell='SRR2141574'
x=merge(dat1[,c(1:7,which(colnames(dat1)==cell))],dat2[,c(1:2,which(colnames(dat1)==cell))], by=1:2)
a=4; b=9
pdf('tmp.pdf')
plot(x[,a], x[,b], pch=16, cex=.5, xlab='Mapability', ylab='# reads',
	main=paste('R=',as.vector(c(cor.test(x[,a], x[,b], method='pearson')$estimate[1])), '; p=', cor.test(x[,a], x[,b], method='pearson')$p.value, sep=''))
dev.off()

dat1=read.table('mda_result.dat2_mapability.txt', header=T)
dat2=read.table('mda_result.dat3_gc.txt', header=T)
x=merge(dat1[,c(1:7,which(colnames(dat1)==cell))],dat2[,c(1:2,which(colnames(dat1)==cell))], by=1:2)
a=6
b=9
pdf('tmp.pdf')
plot(x[,a], x[,b], pch=16, cex=.5, xlab='GC', ylab='# reads',
	main=paste('R=',as.vector(c(cor.test(x[,a], x[,b], method='pearson')$estimate[1])), '; p=', cor.test(x[,a], x[,b], method='pearson')$p.value, sep=''))
dev.off()

dat1=read.table('mda_result.dat4_cnvraw.txt', header=T)
dat2=read.table('mda_result.dat5_cnvcross.txt', header=T)
pdf('tmp.pdf')
plot(dat1[,which(colnames(dat1)==cell)], rowMeans(dat1[, -c(1:7, which(colnames(dat1)==cell))]), pch=16, cex=.5, xlab='Cell', ylab='Other cells')
dev.off()
pdf('tmp.pdf')
plot(dat2[,which(colnames(dat2)==cell)], rowMeans(dat1[, -c(1:7, which(colnames(dat1)==cell))]), pch=16, cex=.5, xlab='Cell', ylab='Other cells')
dev.off()

## genome plot ##
source('manhatten.R')
dat1=read.table('mda_result.dat1_raw.txt', header=T)
tmp=dat1[,which(colnames(dat1)==cell)]
tmp=tmp/median(tmp)*2
pdf('SRR2141574_fig1a_raw.pdf', width=25, height=5)
manhattan.plot(chr=as.vector(dat1$chr), pos=(dat1$pos1+dat1$pos2)/2, pvalue=10^(-tmp), col=c('red','blue'), cex=1, ylim=c(-.5,5), ylab='Depth', xlab='Chromosome (500kb bins)')
dev.off()

dat1=read.table('mda_result.dat3_gc.txt', header=T)
tmp=dat1[,which(colnames(dat1)==cell)]
tmp=tmp/median(tmp)*2
pdf('SRR2141574_fig1b_map_gc.pdf', width=25, height=5)
manhattan.plot(chr=as.vector(dat1$chr), pos=(dat1$pos1+dat1$pos2)/2, pvalue=10^(-tmp), col=c('red','blue'), cex=1, ylim=c(-.5,5), ylab='Depth', xlab='Chromosome (500kb bins)')
dev.off()

dat1=read.table('mda_result.dat5_cnvcross.txt', header=T)
tmp=dat1[,which(colnames(dat1)==cell)]
tmp=tmp/median(tmp)*2
pdf('SRR2141574_fig1c_cross.pdf', width=25, height=5)
manhattan.plot(chr=as.vector(dat1$chr), pos=(dat1$pos1+dat1$pos2)/2, pvalue=10^(-tmp), col=c('red','blue'), cex=1, ylim=c(-.5,5), ylab='Depth', xlab='Chromosome (500kb bins)')
dev.off()

dat1=read.table('mda_result.dat6_cnvsmooth.txt', header=T)
dat2=read.table('mda_result.sccnv.txt', header=T)
tmp1=as.vector(dat1[,which(colnames(dat1)==cell)])
tmp2=as.vector(dat2[,which(colnames(dat2)==cell)])
tmp=c(tmp1,tmp2)
pdf('SRR2141574_fig1d_smooth.pdf', width=25, height=5)
manhattan.plot(chr=as.vector(dat1$chr), pos=(dat1$pos1+dat1$pos2)/2, pvalue=10^(-tmp), col=c('red','blue'), cex=1, ylim=c(-.5,5), ylab='Depth', xlab='Chromosome (500kb bins)')
dev.off()

## Calling figure ##
dat1=read.table('mda_result.dat6_cnvsmooth.txt', header=T)

x=dat1[as.vector(dat1$chr)!='X' & as.vector(dat1$chr)!='Y', which(colnames(dat1)==cell)]
xx=quantile(x, c(0.5-0.382/2,0.5+0.382/2), na.rm=TRUE); sd_data=mean(abs(xx-2))*2 

pdf('tmp.pdf')
plot(density(x, na.rm=TRUE), xlim=c(0, 4.5), ylim=c(0, 3.5), xlab='Normalized copy number', main=paste(cell, ', autosome; black real data, blue simulated', sep=''))
x1=rnorm(length(x), mean=2, sd=sd_data); lines(density(x1), col='blue')
dev.off()

