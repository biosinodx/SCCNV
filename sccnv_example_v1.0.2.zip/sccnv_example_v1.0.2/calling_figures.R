setwd('C:\\Research\\Projects\\Dong X 2016 SCCNV\\mapq30\\')
source('manhatten.R')

batch='ge'
dat1=read.table(paste(batch,'_result.dat6_cnvsmooth.txt', sep=''), header=T)
dat2=read.table(paste(batch, '_result.sccnv.txt', sep=''), header=T)

cells=colnames(dat1)[-c(1:7)]
length(cells)
i=0

	i=i+1
	cell=cells[i]
	tmp1=as.vector(dat1[,which(colnames(dat1)==cell)])
	tmp2=as.vector(dat2[,which(colnames(dat2)==cell)])
	tmp=c(tmp1,tmp2)
	pdf(paste('figures/',cell, '.pdf', sep=''), width=25, height=5)
	manhattan.plot(chr=as.vector(dat1$chr), pos=(dat1$pos1+dat1$pos2)/2, pvalue=10^(-tmp), col=c('red','blue'), cex=1, ylim=c(-.5,5), ylab='Depth', xlab='Chromosome (500kb bins)')
	dev.off()
	print(i)



